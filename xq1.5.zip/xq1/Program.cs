﻿using System;
namespace xq1
{
    class Program
    {
        static void Main(string[] args)
        {
            play p = new play();
         
        }
    }
}
